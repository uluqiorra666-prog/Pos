# POS Pro — Fondations Android / hors ligne

## Ce qui fonctionne dans cette version
- Interface mobile-first sombre avec accents dégradés animés.
- Navigation par pages et bouton Retour.
- Stockage local persistant via IndexedDB.
- Catalogue produits : créer, modifier, prix gros/détail, conditionnement libre, stock et historique des changements de prix.
- Fiches tiers : client, fournisseur ou les deux dans une seule fiche.
- Documents locaux : BL, achat, chargement, retour, facture et versement; lignes d’articles, remise en pourcentage, paiement, livreur.
- Conversion d’un BL en facture avec détection de facture déjà créée.
- Caisse locale : encaissements et décaissements.
- Rappels, priorité, échéance et cases de complétion.
- Journal d’activité, export JSON et restauration.
- Import CSV simple de produits.
- Service worker pour mettre en cache les fichiers de l’application.

## Limites importantes — pas encore une version de production
Cette archive est une fondation utilisable pour le développement, pas encore l'application commerciale complète promise par les exigences.
- La synchronisation multi-appareils et multi-comptes n'est PAS connectée. L'indicateur ne signifie pas que les données ont été envoyées à un serveur.
- Aucun backend, authentification sécurisée, isolation de sociétés, gestion de licence payante ou sauvegarde cloud n'est inclus.
- Les rôles Admin/Comptable/Livreur/Client ne sont pas encore sécurisés côté serveur.
- La gestion des stocks secondaires, le chargement, les retours, les consignes et les écritures comptables doivent être finalisés et testés avant utilisation réelle.
- Les notifications système, l'impression Bluetooth/Wi-Fi, l'arabe RTL complet et les traductions anglaises ne sont pas encore implémentés.
- L'import CSV est une première version : vérifiez les colonnes et faites une sauvegarde avant import.
- Les mentions fiscales et les calculs réglementaires doivent être validés selon votre situation.

## Essai rapide sur PC
1. Décompressez le ZIP.
2. Ouvrez un terminal dans le dossier.
3. Lancez `python -m http.server 8000`.
4. Ouvrez `http://localhost:8000` dans Chrome.
   IndexedDB et le service worker fonctionnent dans un contexte local sécurisé comme localhost.

## Essai sur Android
Pour tester depuis le téléphone, servez le dossier sur un hébergement HTTPS de confiance ou sur le même réseau local (la connexion HTTP locale peut être bloquée par le navigateur). Ouvrez l'adresse dans Chrome et choisissez « Ajouter à l'écran d'accueil » / « Installer l'application ».
Cette archive n'est pas encore un APK. Un APK nécessite un emballage Android (par exemple Capacitor), une configuration de build et une signature.

## Prochaines étapes nécessaires
1. Examiner et intégrer votre ancien projet dès que vous fournissez le ZIP.
2. Ajouter backend API + base de données partagée, authentification et permissions.
3. Ajouter une file de synchronisation transactionnelle avec identifiants d'opérations idempotents, accusés de réception, résolution des conflits et contrôles de stock côté serveur.
4. Mettre en place les sauvegardes cloud automatiques et tests de restauration.
5. Finir les modules métier, impression, notifications, traductions, portail client et licences.
6. Tester les migrations, les cas hors ligne, les conflits de stock et les restaurations avant déploiement.

**Ne l'utilisez pas encore comme système comptable ou stock officiel en production.**
