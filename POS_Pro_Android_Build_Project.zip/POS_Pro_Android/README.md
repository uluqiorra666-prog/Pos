# POS Pro Android project (early build)

This wraps the existing POS Pro offline-first web interface in a native Android WebView shell so it launches as an Android app and uses the Android back button for in-app navigation.

## Build an APK in the cloud (no Android Studio needed)
1. Create a GitHub repository and upload the contents of this folder to its `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build POS Pro APK** and press **Run workflow** (or wait for the first push build).
4. Open the completed workflow run and download the **POS-Pro-debug-APK** artifact. Extract it on your phone and install `app-debug.apk` (Android may ask you to allow installs from that source).

The APK is unsigned for Play Store release; it is suitable for testing/sideloading. A release build needs signing configuration.

## Important limitations
This is an Android wrapper around the current starter, not a finished production POS. It currently stores data locally on that device/browser profile. It does NOT yet provide secure multi-user cloud sync, automatic cloud backups, server-side creator licensing, complete accounting validation, or every requested workflow. Those require backend implementation and testing before business use. Do not use it as the sole record of real transactions.
